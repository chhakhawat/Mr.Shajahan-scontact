package com.shajahan.contact

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.shajahan.contact.data.Contact

class ContactAdapter(
    private val onEditClick: (Contact) -> Unit,
    private val onDeleteClick: (Contact) -> Unit,
    private val onSelectionChanged: (Int) -> Unit
) : ListAdapter<Contact, ContactAdapter.ContactViewHolder>(DiffCallback()) {

    var isSelectMode = false
        set(value) {
            field = value
            if (!value) selectedIds.clear()
            notifyDataSetChanged()
            onSelectionChanged(selectedIds.size)
        }

    private val selectedIds = mutableSetOf<Long>()

    fun getSelectedContacts(): List<Contact> {
        return currentList.filter { selectedIds.contains(it.id) }
    }

    fun clearSelection() {
        selectedIds.clear()
        notifyDataSetChanged()
        onSelectionChanged(0)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return ContactViewHolder(view)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val selectCheckBox: CheckBox = itemView.findViewById(R.id.selectCheckBox)
        private val nameText: TextView = itemView.findViewById(R.id.nameText)
        private val numberText: TextView = itemView.findViewById(R.id.numberText)
        private val callButton: LinearLayout = itemView.findViewById(R.id.callButton)
        private val whatsappButton: LinearLayout = itemView.findViewById(R.id.whatsappButton)
        private val imoButton: LinearLayout = itemView.findViewById(R.id.imoButton)
        private val editButton: LinearLayout = itemView.findViewById(R.id.editButton)
        private val deleteButton: LinearLayout = itemView.findViewById(R.id.deleteButton)

        fun bind(contact: Contact) {
            nameText.text = contact.name
            numberText.text = contact.phoneNumber

            // Checkbox visibility & state
            selectCheckBox.visibility = if (isSelectMode) View.VISIBLE else View.GONE
            selectCheckBox.setOnCheckedChangeListener(null)
            selectCheckBox.isChecked = selectedIds.contains(contact.id)
            selectCheckBox.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) selectedIds.add(contact.id)
                else selectedIds.remove(contact.id)
                onSelectionChanged(selectedIds.size)
            }

            // Also allow clicking the card to toggle in select mode
            itemView.setOnClickListener {
                if (isSelectMode) {
                    selectCheckBox.isChecked = !selectCheckBox.isChecked
                }
            }

            callButton.setOnClickListener {
                if (isSelectMode) {
                    // In select mode, apply to all selected if any, else this one
                    val targets = if (selectedIds.isNotEmpty()) getSelectedContacts() else listOf(contact)
                    targets.forEach { openDialer(it.phoneNumber) }
                } else {
                    openDialer(contact.phoneNumber)
                }
            }

            whatsappButton.setOnClickListener {
                if (isSelectMode && selectedIds.isNotEmpty()) {
                    getSelectedContacts().forEach { openWhatsApp(it.phoneNumber) }
                } else {
                    openWhatsApp(contact.phoneNumber)
                }
            }

            imoButton.setOnClickListener {
                if (isSelectMode && selectedIds.isNotEmpty()) {
                    getSelectedContacts().forEach { openIMO(it.phoneNumber) }
                } else {
                    openIMO(contact.phoneNumber)
                }
            }

            editButton.setOnClickListener {
                if (!isSelectMode) onEditClick(contact)
            }

            deleteButton.setOnClickListener {
                if (!isSelectMode) onDeleteClick(contact)
            }
        }

        private fun openDialer(phone: String) {
            try {
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:$phone")
                }
                itemView.context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(itemView.context, "কল করতে পারছি না", Toast.LENGTH_SHORT).show()
            }
        }

        private fun openWhatsApp(phone: String) {
            try {
                var number = phone.filter { it.isDigit() }
                if (number.startsWith("0") && number.length == 11) {
                    number = "88$number"
                } else if (!number.startsWith("88") && number.length == 10) {
                    number = "880$number"
                }
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://api.whatsapp.com/send?phone=$number")
                    setPackage("com.whatsapp")
                }
                itemView.context.startActivity(intent)
            } catch (e: Exception) {
                try {
                    var number = phone.filter { it.isDigit() }
                    if (number.startsWith("0") && number.length == 11) number = "88$number"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number"))
                    itemView.context.startActivity(intent)
                } catch (ex: Exception) {
                    Toast.makeText(itemView.context, "WhatsApp খোলা যায়নি", Toast.LENGTH_SHORT).show()
                }
            }
        }

        private fun openIMO(phone: String) {
            try {
                var number = phone.filter { it.isDigit() }
                if (number.startsWith("0") && number.length == 11) number = "88$number"
                val imoIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("imo://profile?phone=$number")
                    setPackage("com.imo.android.imoim")
                }
                itemView.context.startActivity(imoIntent)
            } catch (e: Exception) {
                try {
                    val intent = itemView.context.packageManager
                        .getLaunchIntentForPackage("com.imo.android.imoim")
                    if (intent != null) {
                        itemView.context.startActivity(intent)
                        Toast.makeText(itemView.context, "IMO খুলুন: $phone", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(itemView.context, "IMO ইন্সটল করা নেই", Toast.LENGTH_SHORT).show()
                    }
                } catch (ex: Exception) {
                    Toast.makeText(itemView.context, "IMO খোলা যায়নি", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Contact>() {
        override fun areItemsTheSame(oldItem: Contact, newItem: Contact) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Contact, newItem: Contact) = oldItem == newItem
    }
}
