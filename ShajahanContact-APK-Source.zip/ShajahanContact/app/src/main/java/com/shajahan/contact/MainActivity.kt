package com.shajahan.contact

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.shajahan.contact.data.Contact
import com.shajahan.contact.data.ContactRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var repository: ContactRepository
    private lateinit var adapter: ContactAdapter
    private lateinit var searchEditText: EditText
    private lateinit var micButton: ImageButton
    private lateinit var recyclerView: RecyclerView
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyText: TextView
    private lateinit var markButton: LinearLayout
    private lateinit var markButtonText: TextView
    private lateinit var deleteAllButton: LinearLayout
    private lateinit var selectionActionBar: LinearLayout
    private lateinit var selectedCountText: TextView
    private lateinit var deleteSelectedButton: LinearLayout

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var searchJob: Job? = null
    private var hasSpokenWelcome = false
    private var currentQuery = ""

    private val contactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            // If already have contacts, re-import; else first-time flow
            lifecycleScope.launch {
                if (repository.getCount() > 0) reImportFromPhone()
                else startImportOrRestore()
            }
        } else {
            statusText.text = "কন্টাক্ট পড়ার অনুমতি দিতে হবে"
            statusText.visibility = View.VISIBLE
            Toast.makeText(this, "অনুমতি না দিলে কন্টাক্ট দেখা যাবে না", Toast.LENGTH_LONG).show()
        }
    }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Toast.makeText(this, "মাইক্রোফোন প্রস্তুত", Toast.LENGTH_SHORT).show()
            setupSpeechRecognizer()
        } else {
            Toast.makeText(this, "মাইক অনুমতি না দিলে ভয়েস সার্চ কাজ করবে না", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = ContactRepository(this)
        initViews()
        setupRecycler()
        setupSearch()
        setupMicButton()
        setupTopButtons()

        tts = TextToSpeech(this, this)
        checkAndRequestPermissions()
    }

    private fun initViews() {
        searchEditText = findViewById(R.id.searchEditText)
        micButton = findViewById(R.id.micButton)
        recyclerView = findViewById(R.id.contactsRecyclerView)
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)
        emptyText = findViewById(R.id.emptyText)
        markButton = findViewById(R.id.markButton)
        markButtonText = findViewById(R.id.markButtonText)
        deleteAllButton = findViewById(R.id.deleteAllButton)
        selectionActionBar = findViewById(R.id.selectionActionBar)
        selectedCountText = findViewById(R.id.selectedCountText)
        deleteSelectedButton = findViewById(R.id.deleteSelectedButton)
        // Import + Add
        findViewById<LinearLayout>(R.id.importContactsButton).setOnClickListener {
            // Re-request contacts permission if needed then import
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
            } else {
                reImportFromPhone()
            }
        }
        findViewById<LinearLayout>(R.id.addContactButton).setOnClickListener {
            showAddContactDialog()
        }
    }

    private fun setupRecycler() {
        adapter = ContactAdapter(
            onEditClick = { contact -> showEditDialog(contact) },
            onDeleteClick = { contact -> showDeleteConfirmDialog(contact) },
            onSelectionChanged = { count ->
                if (count > 0) {
                    selectionActionBar.visibility = View.VISIBLE
                    selectedCountText.text = "$count টি সিলেক্টেড"
                } else {
                    selectionActionBar.visibility = View.GONE
                }
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupTopButtons() {
        // Mark / Select mode toggle
        markButton.setOnClickListener {
            adapter.isSelectMode = !adapter.isSelectMode
            if (adapter.isSelectMode) {
                markButtonText.text = "✕ বাতিল"
                Toast.makeText(this, "মার্ক মোড চালু – কন্টাক্ট সিলেক্ট করুন", Toast.LENGTH_SHORT).show()
            } else {
                markButtonText.text = "✓ মার্ক"
                adapter.clearSelection()
            }
        }

        // Delete All – requires TWO confirmations
        deleteAllButton.setOnClickListener {
            showDeleteAllFirstConfirm()
        }

        // Delete selected
        deleteSelectedButton.setOnClickListener {
            val selected = adapter.getSelectedContacts()
            if (selected.isEmpty()) {
                Toast.makeText(this, "কোনো কন্টাক্ট সিলেক্ট করা নেই", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setTitle("সিলেক্টেড ডিলিট?")
                .setMessage("${selected.size} টি কন্টাক্ট মুছে ফেলতে চান?")
                .setPositiveButton("হ্যাঁ, ডিলিট") { _, _ ->
                    lifecycleScope.launch {
                        selected.forEach { repository.deleteContact(it) }
                        adapter.clearSelection()
                        adapter.isSelectMode = false
                        markButtonText.text = "✓ মার্ক"
                        Toast.makeText(this@MainActivity, "${selected.size} টি ডিলিট হয়েছে", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("না", null)
                .show()
        }
    }

    /** Delete All – First confirmation */
    private fun showDeleteAllFirstConfirm() {
        AlertDialog.Builder(this)
            .setTitle("সব কন্টাক্ট ডিলিট?")
            .setMessage("আপনি কি সত্যিই সব কন্টাক্ট মুছে ফেলতে চান?\n\nএটি ফায়ারবেস থেকেও মুছে যাবে।")
            .setPositiveButton("হ্যাঁ, এগিয়ে যান") { _, _ ->
                // Second confirmation
                showDeleteAllSecondConfirm()
            }
            .setNegativeButton("না, থাক", null)
            .show()
    }

    /** Delete All – Second confirmation (must confirm twice) */
    private fun showDeleteAllSecondConfirm() {
        AlertDialog.Builder(this)
            .setTitle("শেষবার নিশ্চিত করুন")
            .setMessage("এখন ডিলিট করলে আর ফিরে পাওয়া যাবে না।\n\nসত্যিই সব মুছে ফেলবেন?")
            .setPositiveButton("হ্যাঁ, সব ডিলিট করো") { _, _ ->
                lifecycleScope.launch {
                    repository.clearAll()
                    adapter.clearSelection()
                    adapter.isSelectMode = false
                    markButtonText.text = "✓ মার্ক"
                    Toast.makeText(this@MainActivity, "সব কন্টাক্ট ডিলিট হয়েছে", Toast.LENGTH_LONG).show()
                }
            }
            }
            .setNegativeButton("না, বাতিল", null)
            .show()
    }

    private fun setupSearch() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchJob?.cancel()
                searchJob = lifecycleScope.launch {
                    delay(300)
                    currentQuery = s?.toString()?.trim() ?: ""
                    observeContacts(currentQuery)
                }
            }
        })
    }

    private fun setupMicButton() {
        micButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                return@setOnClickListener
            }
            startListening()
        }
    }

    private fun checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        } else {
            startImportOrRestore()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micButton.postDelayed({
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }, 1500)
        } else {
            setupSpeechRecognizer()
        }
    }

    private fun startImportOrRestore() {
        lifecycleScope.launch {
            showLoading(true, getString(R.string.importing))
            val localCount = repository.getCount()
            if (localCount == 0) {
                val restored = repository.restoreFromFirebaseIfNeeded()
                if (restored > 0) {
                    showLoading(false, null)
                    Toast.makeText(this@MainActivity, "$restored টি কন্টাক্ট ফায়ারবেস থেকে এসেছে", Toast.LENGTH_LONG).show()
                    observeContacts("")
                    speakWelcome()
                    return@launch
                }
                val imported = repository.importFromPhoneAndSync()
                showLoading(false, null)
                if (imported > 0) {
                    Toast.makeText(this@MainActivity, "$imported টি কন্টাক্ট ইমপোর্ট হয়েছে", Toast.LENGTH_LONG).show()
                } else {
                    statusText.text = "কোনো কন্টাক্ট পাওয়া যায়নি"
                    statusText.visibility = View.VISIBLE
                }
            } else {
                showLoading(false, null)
            }
            observeContacts("")
            speakWelcome()
        }
    }

    private fun observeContacts(query: String) {
        lifecycleScope.launch {
            repository.searchContacts(query).collectLatest { list ->
                adapter.submitList(list)
                emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                recyclerView.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    private fun showLoading(show: Boolean, message: String?) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        if (message != null) {
            statusText.text = message
            statusText.visibility = View.VISIBLE
        } else {
            statusText.visibility = View.GONE
        }
    }


    private fun reImportFromPhone() {
        lifecycleScope.launch {
            showLoading(true, "কন্টাক্ট ইমপোর্ট হচ্ছে...")
            val imported = repository.importFromPhoneAndSync()
            showLoading(false, null)
            if (imported > 0) {
                Toast.makeText(this@MainActivity, "$imported টি কন্টাক্ট ইমপোর্ট হয়েছে", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@MainActivity, "কোনো নতুন কন্টাক্ট পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
            observeContacts(currentQuery)
        }
    }

    private fun showAddContactDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 30, 40, 10)
        }
        val nameLabel = TextView(this).apply {
            text = "নাম"; textSize = 18f; setTextColor(0xFF000000.toInt())
        }
        val nameInput = EditText(this).apply {
            hint = "নাম লিখুন"; textSize = 20f; setTextColor(0xFF000000.toInt()); setSingleLine()
        }
        val numberLabel = TextView(this).apply {
            text = "নাম্বার"; textSize = 18f; setTextColor(0xFF000000.toInt()); setPadding(0, 20, 0, 0)
        }
        val numberInput = EditText(this).apply {
            hint = "01XXXXXXXXX"; textSize = 20f; setTextColor(0xFF000000.toInt())
            setSingleLine(); inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        layout.addView(nameLabel); layout.addView(nameInput)
        layout.addView(numberLabel); layout.addView(numberInput)

        AlertDialog.Builder(this)
            .setTitle("নতুন কন্টাক্ট")
            .setView(layout)
            .setPositiveButton("সেভ") { _, _ ->
                val newName = nameInput.text.toString().trim()
                val newNumber = numberInput.text.toString().trim()
                if (newName.isBlank() || newNumber.isBlank()) {
                    Toast.makeText(this, "নাম ও নাম্বার খালি রাখা যাবে না", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                lifecycleScope.launch {
                    repository.addContact(newName, newNumber)
                    Toast.makeText(this@MainActivity, "যোগ হয়েছে", Toast.LENGTH_SHORT).show()
                    observeContacts(currentQuery)
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showEditDialog(contact: Contact) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 30, 40, 10)
        }
        val nameLabel = TextView(this).apply {
            text = "নাম"; textSize = 18f; setTextColor(0xFF000000.toInt())
        }
        val nameInput = EditText(this).apply {
            setText(contact.name); textSize = 20f; setTextColor(0xFF000000.toInt()); setSingleLine()
        }
        val numberLabel = TextView(this).apply {
            text = "নাম্বার"; textSize = 18f; setTextColor(0xFF000000.toInt()); setPadding(0, 20, 0, 0)
        }
        val numberInput = EditText(this).apply {
            setText(contact.phoneNumber); textSize = 20f; setTextColor(0xFF000000.toInt())
            setSingleLine(); inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        layout.addView(nameLabel); layout.addView(nameInput)
        layout.addView(numberLabel); layout.addView(numberInput)

        AlertDialog.Builder(this)
            .setTitle("এডিট করুন")
            .setView(layout)
            .setPositiveButton("সেভ") { _, _ ->
                val newName = nameInput.text.toString().trim()
                val newNumber = numberInput.text.toString().trim()
                if (newName.isBlank() || newNumber.isBlank()) {
                    Toast.makeText(this, "নাম ও নাম্বার খালি রাখা যাবে না", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                lifecycleScope.launch {
                    repository.updateContact(contact.copy(name = newName, phoneNumber = newNumber))
                    Toast.makeText(this@MainActivity, "আপডেট হয়েছে", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showDeleteConfirmDialog(contact: Contact) {
        AlertDialog.Builder(this)
            .setTitle("ডিলিট করবেন?")
            .setMessage("\"${contact.name}\" কে মুছে ফেলতে চান?\n\nএটি আর ফিরে পাওয়া যাবে না।")
            .setPositiveButton("হ্যাঁ, ডিলিট") { _, _ ->
                lifecycleScope.launch {
                    repository.deleteContact(contact)
                    Toast.makeText(this@MainActivity, "ডিলিট হয়েছে", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("না", null)
            .show()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            }
            tts?.setSpeechRate(0.9f)
        }
    }

    private fun speakWelcome() {
        if (hasSpokenWelcome) return
        hasSpokenWelcome = true
        tts?.speak(getString(R.string.welcome_message), TextToSpeech.QUEUE_FLUSH, null, "welcome")
    }

    private fun setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = getString(R.string.listening)
                statusText.visibility = View.VISIBLE
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.visibility = View.GONE }
            override fun onError(error: Int) {
                statusText.visibility = View.GONE
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "কিছু বোঝা যায়নি, আবার বলুন"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কিছু শোনা যায়নি"
                    else -> "ভয়েস এরর"
                }
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                statusText.visibility = View.GONE
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spoken = matches[0]
                    handleVoiceCommand(spoken)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }


    /**
     * Voice command:
     * - "করিম" → search
     * - "করিমকে কল দাও" / "কল করো করিম" → dial
     * - "করিম হোয়াটসঅ্যাপ" / "whatsapp করিম" → WhatsApp
     * - "করিম ইমো" / "imo করিম" → IMO
     */
    private fun handleVoiceCommand(spokenRaw: String) {
        val spoken = spokenRaw.trim()
        searchEditText.setText(spoken)
        searchEditText.setSelection(spoken.length)

        val lower = spoken.lowercase()
            .replace("।", " ")
            .replace(".", " ")

        val wantCall = listOf("কল", "call", "ফোন", "ডাক").any { lower.contains(it) }
        val wantWa = listOf("হোয়াটসঅ্যাপ", "হোয়াটসঅ্যাপ", "whatsapp", "হোয়াটস", "ওয়াটসঅ্যাপ", "wa ").any { lower.contains(it) } ||
                lower.contains("whats app")
        val wantImo = listOf("ইমো", "imo", "ইমু").any { lower.contains(it) }

        // Strip command words to get name part
        var nameQuery = spoken
        val stripWords = listOf(
            "কে", "কেও", "কো", "কে ", "কে কল", "কল দাও", "কল দিও", "কল করো", "কল কর",
            "দাও", "দিও", "করো", "কর", "দে", "দিয়ে", "দিয়ে", "ফোন", "call", "dial",
            "হোয়াটসঅ্যাপে", "হোয়াটসঅ্যাপে", "হোয়াটসঅ্যাপ", "হোয়াটসঅ্যাপ", "whatsapp",
            "মেসেজ", "মেসেজ দাও", "চ্যাট", "ইমোতে", "ইমো", "imo", "ইমু",
            "নাম্বারে", "নাম্বার", "অমুক", "এর", "কে দাও"
        )
        for (w in stripWords) {
            nameQuery = nameQuery.replace(w, " ", ignoreCase = true)
        }
        nameQuery = nameQuery.replace(Regex("\\s+"), " ").trim()

        if (nameQuery.isBlank()) {
            nameQuery = spoken // fallback full text search
        }

        // Put cleaned name in search
        if (nameQuery != spoken) {
            searchEditText.setText(nameQuery)
            searchEditText.setSelection(nameQuery.length)
        }

        lifecycleScope.launch {
            delay(450)
            val filtered = adapter.currentList.filter { c ->
                c.name.contains(nameQuery, ignoreCase = true) ||
                    c.phoneNumber.contains(nameQuery) ||
                    nameQuery.split(" ").any { part ->
                        part.length >= 2 && c.name.contains(part, ignoreCase = true)
                    }
            }

            if (filtered.isEmpty()) {
                // still show search results from text watcher
                Toast.makeText(this@MainActivity, "কোনো মিল পাওয়া যায়নি: $nameQuery", Toast.LENGTH_SHORT).show()
                return@launch
            }

            val target = filtered.first()

            when {
                wantCall -> {
                    Toast.makeText(this@MainActivity, "কল: ${target.name}", Toast.LENGTH_SHORT).show()
                    try {
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = android.net.Uri.parse("tel:${target.phoneNumber}")
                        }
                        startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "কল খোলা যায়নি", Toast.LENGTH_SHORT).show()
                    }
                }
                wantWa -> {
                    Toast.makeText(this@MainActivity, "WhatsApp: ${target.name}", Toast.LENGTH_SHORT).show()
                    openWhatsAppNumber(target.phoneNumber)
                }
                wantImo -> {
                    Toast.makeText(this@MainActivity, "IMO: ${target.name}", Toast.LENGTH_SHORT).show()
                    openImoNumber(target.phoneNumber)
                }
                else -> {
                    // just search — list already updating via text watcher
                    if (filtered.size == 1) {
                        Toast.makeText(this@MainActivity, "পাওয়া গেছে: ${target.name}", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, "${filtered.size} টি মিল", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun openWhatsAppNumber(phone: String) {
        try {
            var number = phone.filter { it.isDigit() }
            if (number.startsWith("0") && number.length == 11) number = "88$number"
            else if (!number.startsWith("88") && number.length == 10) number = "880$number"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse("https://api.whatsapp.com/send?phone=$number")
                setPackage("com.whatsapp")
            }
            startActivity(intent)
        } catch (e: Exception) {
            try {
                var number = phone.filter { it.isDigit() }
                if (number.startsWith("0") && number.length == 11) number = "88$number"
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$number")))
            } catch (ex: Exception) {
                Toast.makeText(this, "WhatsApp খোলা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openImoNumber(phone: String) {
        try {
            var number = phone.filter { it.isDigit() }
            if (number.startsWith("0") && number.length == 11) number = "88$number"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse("imo://profile?phone=$number")
                setPackage("com.imo.android.imoim")
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "IMO খোলা যায়নি / ইন্সটল নেই", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startListening() {
        if (speechRecognizer == null) setupSpeechRecognizer()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "মাইক শুরু করা যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
